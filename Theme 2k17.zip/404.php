<?php get_header('single'); ?>
<div class="col-md-12 wrap404">
    <div class="cont404 col-md-offset-2 col-md-8">
   <h1>Page Not Found</h1>
    <hr>
    <h3>You're looking for something that doesn't exist</h3>
    </div>
</div>
<?php get_footer(); ?>
