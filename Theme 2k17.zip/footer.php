<footer>
    <?php wp_footer(); ?>
    <div class="col-md-12 foot">
        <p>Theme By Kogul</p>
    </div>
</footer>
</body>
</html>