<?php

if(is_active_sidebar('k_sidebar')){
    dynamic_sidebar('k_sidebar');
}